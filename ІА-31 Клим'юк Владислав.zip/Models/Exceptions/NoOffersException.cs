﻿namespace Models.Exceptions
{
    public class NoOffersException : Exception
    {
    }
}
