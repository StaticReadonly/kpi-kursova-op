﻿namespace Models.ControllerModels
{
    public class UserOffersModel
    {
        public int Page { get; set; } = 1;
    }
}
