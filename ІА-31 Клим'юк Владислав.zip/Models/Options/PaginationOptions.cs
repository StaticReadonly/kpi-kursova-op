﻿namespace Models.Options
{
    public class PaginationOptions
    {
        public int ItemsPerPage { get; set; }
    }
}
