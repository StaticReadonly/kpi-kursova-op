﻿using Models.ViewModels;

namespace Models.ControllerModels
{
    public class UserTenderOffersModel
    {
        public int Page { get; set; } = 1;
        public Guid Id { get; set; }
    }
}
