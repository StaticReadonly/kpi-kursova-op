﻿namespace Models.ViewModels
{
    public class OffererViewModel
    {
        public string Name { get; set; } = string.Empty;
        public string Surname { get; set; } = string.Empty;
        public string Patronimyc { get; set; } = string.Empty;
    }
}
